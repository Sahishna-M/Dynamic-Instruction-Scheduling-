#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "sim_proc.h"
#include <vector>
#include <iostream>
using namespace std;

/*  argc holds the number of command line arguments
    argv[] holds the commands themselves
    Example:-
    sim 256 32 4 gcc_trace.txt
    argc = 5
    argv[0] = "sim"
    argv[1] = "256"
    argv[2] = "32"
    ... and so on
*/



//DEFINITIONS
FILE *FP;               // File handler
char *trace_file;       // Variable that holds trace file name;
proc_params params;       // look at sim_bp.h header file for the the definition of struct proc_params
int op_type, dest, src1, src2;  // Variables are read from trace file
uint64_t pc; // Variable holds the pc read from input file
int instruction_number = 0; // assigns the instruction number to each instruction
bool trace_done = false;
int global_counter = 0;
int cycle_start = 0;

struct instructions
{
    int seq_no = 0;
    int operation_type = 0;
    int source1 = 0;
    int source2 = 0;
    int destination = 0;
    bool arf_source1 = false;  //to check if the value is from arf
    bool arf_source2 = false;  //to check if the value is from arf
    bool rmt_source1 = false;  //to check if the value is from rmt
    bool rmt_source2 = false;  //to check if the value is from rmt
    int fe_start = -1, fe_duration = 0;
    int de_start = -1, de_duration = 0;
    int rn_start = -1, rn_duration = 0;
    int rr_start = -1, rr_duration = 0;
    int di_start = -1, di_duration = 0;
    int is_start = -1, is_duration = 0;
    int ex_start = -1, ex_duration = 0;
    int wb_start = -1, wb_duration = 0;
    int rt_start = -1, rt_duration = 0;
    int program_counter = 0;
    int dst_rob_tag = -1;
};



struct rob_new_value
{
    int tag;
    instructions instr;
    int value = 0;
    int dst = 0;
    bool ready = false;
    int rob_pc;
    bool valid = false;
};

struct rmt_table
{
    bool valid;
    int rmt_rob_tag;
};

std::vector<instructions> instruction;

std::vector<rob_new_value> rob;

int rob_head = 0;
int rob_tail = 0;
int rob_count = 0;

int issue_count = 0;

std::vector<rmt_table> rmt;

std::vector<instructions> DE;               //Decode bundle

struct wait_instr
{
    instructions waiting_instruct;

    bool src1_ready = false;

    bool src2_ready = false;

};

std::vector<wait_instr> RN;               //Rename bundle

std::vector<wait_instr> RR;               //Register Read bundle

std::vector<wait_instr> DI;              //Dispatch bundle

struct issue_queue
{
    bool valid = false;
    wait_instr queued;
};

std::vector<issue_queue> IQ;              //Issue Queue bundle

struct execution
{
    wait_instr instruct;
    int latency = 0;
    bool valid = false;
    int execution_time = 0;
};

std::vector<execution> execute_list;  //Execute bundle

std::vector<execution> WB;  //Writeback bundle

int instruction_count; // To check which instruction is being fetched/run

void Retire();

void Writeback();

void Execute();

void Issue();

void Dispatch();

void RegRead();

void Rename();

void Decode();

void Fetch();

bool Advance_Cycle();

int main (int argc, char* argv[])
{
    if (argc != 5)
    {
        printf("Error: Wrong number of inputs:%d\n", argc-1);
        exit(EXIT_FAILURE);
    }

    params.rob_size     = strtoul(argv[1], NULL, 10);
    params.iq_size      = strtoul(argv[2], NULL, 10);
    params.width        = strtoul(argv[3], NULL, 10);
    trace_file          = argv[4];

   /* printf("rob_size:%lu "
            "iq_size:%lu "
            "width:%lu "
            "tracefile:%s\n", params.rob_size, params.iq_size, params.width, trace_file);*/

    // Open trace_file in read mode
    FP = fopen(trace_file, "r");
    if(FP == NULL)
    {
        // Throw error and exit if fopen() failed
        printf("Error: Unable to open file %s\n", trace_file);
        exit(EXIT_FAILURE);
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // The following loop just tests reading the trace and echoing it back to the screen.
    //
    // Replace this loop with the "do { } while (Advance_Cycle());" loop indicated in the Project 3 spec.
    // Note: fscanf() calls -- to obtain a fetch bundle worth of instructions from the trace -- should be
    // inside the Fetch() function.
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////

    // Resize RMT
    rmt.resize(67); // Size of RMT

    for(int i = 0; i < 67; i++)
    {
        
        rmt[i].valid = false;
        rmt[i].rmt_rob_tag = -1;           // no rob_tag
    }

    // Resize rob
    rob.resize(params.rob_size);

    // Resize pipeline registers
    IQ.resize(params.iq_size);
    execute_list.resize(params.width*5);
    WB.resize(params.width*5);

    do {
        Retire();
  
        Writeback();

        Execute();

        Issue();

        Dispatch();

        RegRead();

        Rename();

        Decode();

        Fetch();
    } while (Advance_Cycle());

    cout<<"# === Simulator Command ========="<<endl;
    printf("# ./sim %lu %lu %lu %s\n", params.rob_size, params.iq_size, params.width, trace_file);
    cout<<"# === Processor Configuration ==="<<endl;
    cout<<"# ROB_SIZE = "<<params.rob_size<<endl;
    cout<<"# IQ_SIZE  = "<<params.iq_size<<endl;
    cout<<"# WIDTH    = "<<params.width<<endl;   
    cout<<"# === Simulation Results ========"<<endl;   
    cout<<"# Dynamic Instruction Count    = "<< instruction_number<<endl;
    cout<<"# Cycles                       = "<< cycle_start<<endl;
    printf("# Instructions Per Cycle (IPC) = %.2lf\n", double(instruction_number)/double(cycle_start));  
    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////// FETCH() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Do nothing if either (1) there are no
// more instructions in the trace file or
// (2) DE is not empty (cannot accept a new
// decode bundle).
//
// If there are more instructions in the
// trace file and if DE is empty (can accept
// a new decode bundle), then fetch up to
// WIDTH instructions from the trace file
// into DE. Fewer than WIDTH instructions
// will be fetched only if the trace file
// has fewer than WIDTH instructions left.

void Fetch()
{
    int count = 0;
    if(!DE.empty())
    {
        return;    
    }  //fetch will be stalled


    while(count < params.width && !trace_done)  // checking if all 5 parameters rare fetched correctly
    {
        int read = fscanf(FP, "%lx %d %d %d %d", &pc, &op_type, &dest, &src1, &src2);  // checking if all 5 parameters rare fetched correctly

        if(read == 5)
        {      
            //printf("%lx %d %d %d %d\n", pc, op_type, dest, src1, src2); //Print to check if inputs have been read correctly        
            instructions temp;
            temp.seq_no = instruction_number;
            temp.operation_type = op_type;
            temp.source1 = src1;
            temp.source2 = src2;
            temp.destination = dest;
            temp.program_counter = pc;
            temp.arf_source1 = false;
            temp.arf_source2 = false;
            temp.rmt_source1 = false;
            temp.rmt_source2 = false;
            temp.fe_start = cycle_start;
            temp.de_start = cycle_start + 1;
            //temp.fe_duration++;
            DE.push_back(temp);
            //global_counter ++;
            count++;
            instruction_number++;
        }
        else
        {
            trace_done = true;
            break;
        }
    }
    }

///////////////////////////////////////////////////////////////////////////////////////////// DECODE() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// If DE contains a decode bundle:
// If RN is not empty (cannot accept a new
// rename bundle), then do nothing.
// If RN is empty (can accept a new rename
// bundle), then advance the decode bundle
// from DE to RN.

void Decode()
{
    if(!DE.empty())    // checking if decode bundle is not empty
    {
        if(!RN.empty())    return; // do nothing

        else
        {
            //RN.resize(params.width);
            for(int i = 0; i < DE.size(); i++)
            {
                DE[i].rn_start = cycle_start + 1;
                RN.push_back({(DE[i]), false, false});
            }
            DE.clear();
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////////////// RENAME() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// If RN contains a rename bundle:
// If either RR is not empty (cannot accept
// a new register-read bundle) or the ROB
// does not have enough free entries to
// accept the entire rename bundle, then do
// nothing.
// If RR is empty (can accept a new
// register-read bundle) and the ROB has
// enough free entries to accept the entire
// rename bundle, then process (see below)
// the rename bundle and advance it from
// RN to RR.

void Rename()
{
    int free_rob_entries = params.rob_size - rob_count;
    if(!RN.empty())
    {
        if((!RR.empty()) || free_rob_entries < RN.size()) return;

        if(RR.empty() && free_rob_entries >= RN.size())
        {
            for(int i = 0; i < RN.size(); i++)
            {
                int src1_reg = RN[i].waiting_instruct.source1;
                int src2_reg = RN[i].waiting_instruct.source2;
                int dst_reg = RN[i].waiting_instruct.destination;
                int rob_tag = rob_tail;

                // Allocate an entry in ROB for the instruction                              
                rob[rob_tail].tag = rob_tail;
                rob[rob_tail].instr = RN[i].waiting_instruct;
                rob[rob_tail].value = 0;
                rob[rob_tail].dst = dst_reg;
                rob[rob_tail].ready = false;
                rob[rob_tail].rob_pc = RN[i].waiting_instruct.program_counter;
                rob[rob_tail].valid = true;

                //Rename the the source register 1
                if(src1_reg != -1 )
                {
                    if(rmt[src1_reg].valid) //is it in rmt
                    {
                        RN[i].waiting_instruct.source1 = rmt[src1_reg].rmt_rob_tag;
                        RN[i].src1_ready = false;
                        RN[i].waiting_instruct.rmt_source1 = true;
                        RN[i].waiting_instruct.arf_source1 = false;
                    }  

                    else      
                    {
                        RN[i].waiting_instruct.source1 = src1_reg;
                        RN[i].src1_ready = true;
                        RN[i].waiting_instruct.rmt_source1 = false;
                        RN[i].waiting_instruct.arf_source1 = true;
                    }
                }

               else
                {
                    RN[i].src1_ready = true;
                }

                //Rename the the source register 2
                if(src2_reg != -1 )
                {
                    if(rmt[src2_reg].valid)  //rmt
                    {
                        RN[i].waiting_instruct.source2 = rmt[src2_reg].rmt_rob_tag;
                        RN[i].src2_ready = false;
                        RN[i].waiting_instruct.rmt_source2 = true;
                        RN[i].waiting_instruct.arf_source2 = false;
                    }  

                    else      
                    {
                        RN[i].waiting_instruct.source2 = src2_reg;
                        RN[i].src2_ready = true;
                        RN[i].waiting_instruct.rmt_source2 = false;
                        RN[i].waiting_instruct.arf_source2 = true;
                    }
                }

                else
                {
                    RN[i].src2_ready = true;
                }

                // Destination register handling
                if(dst_reg != -1)
                {
                    // Update the rob tag of the particular destination register in rmt
                    rmt[dst_reg].valid = true;
                    rmt[dst_reg].rmt_rob_tag = rob_tail;

                   // Rename the destination register of the instruction
                    //RN[i].waiting_instruct.destination = rob_tail;
                }

                RN[i].waiting_instruct.dst_rob_tag = rob_tail;

                rob_tail = (rob_tail + 1) % params.rob_size;
                rob_count++;

                RN[i].waiting_instruct.rr_start = cycle_start + 1;
                rob[RN[i].waiting_instruct.dst_rob_tag].instr.rr_start = RN[i].waiting_instruct.rr_start;

                RR.push_back(RN[i]);
                //if(RN[i].waiting_instruct.rn_start == -1)  RN[i].waiting_instruct.rn_start = global_counter;
            }
        }
        RN.clear();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////// REGREAD() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// If RR contains a register-read bundle:
// If DI is not empty (cannot accept a
// new dispatch bundle), then do nothing.
// If DI is empty (can accept a new dispatch
// bundle), then process (see below) the
// register-read bundle and advance it from
// RR to DI.
//
// Since values are not explicitly modeled,
// the sole purpose of the Register Read
// stage is to ascertain the readiness of
// the renamed source operands.
//
// Also take care that producers in their
// last cycle of execution wakeup dependent
// operands not just in the IQ, but also in
// two other stages including RegRead()
// (this is required to avoid deadlock). See
// Execute() description above.

void RegRead()
{
    if(!RR.empty())
    {
        if(!DI.empty()) return;
    
            for(int i = 0; i < RR.size(); i++)
            {
                int s1 = RR[i].waiting_instruct.source1;
                int s2 = RR[i].waiting_instruct.source2;
            
                if(RR[i].waiting_instruct.rmt_source1)
                {
                    int tag1 = RR[i].waiting_instruct.source1;
                    if(rob[tag1].ready || !rob[tag1].valid)         RR[i].src1_ready = true;
                }

                if(RR[i].waiting_instruct.rmt_source2)
                {
                    int tag2 = RR[i].waiting_instruct.source2;
                    if(rob[tag2].ready || !rob[tag2].valid)         RR[i].src2_ready = true;
                }

                RR[i].waiting_instruct.di_start = cycle_start + 1;
                int rob_tag = RR[i].waiting_instruct.dst_rob_tag;
                rob[rob_tag].instr.di_start = RR[i].waiting_instruct.di_start;

                DI.push_back(RR[i]);
            }
            RR.clear();
    }
         
}


///////////////////////////////////////////////////////////////////////////////////////////// DISPATCH() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// If DI contains a dispatch bundle:
// If the number of free IQ entries is less
// than the size of the dispatch bundle in
// DI, then do nothing. If the number of
// free IQ entries is greater than or equal
// to the size of the dispatch bundle in DI,
// then dispatch all instructions from DI to
// the IQ.

void Dispatch()
{
    int free_iq = 0;
    for(int i  = 0; i < params.iq_size; i++)
    {
        if(!IQ[i].valid)
        {
            free_iq++;
        }
    }

    if(!DI.empty())
    {
        if(free_iq < DI.size())  return;

        else
        {
            int di_index = 0;
            for(int i = 0; i < params.iq_size && di_index < DI.size(); i++ )
            {
                //Write to empty spot in IQ

                if(!IQ[i].valid)
                {
                    DI[di_index].waiting_instruct.is_start = cycle_start + 1;

                    int rob_tag = DI[di_index].waiting_instruct.dst_rob_tag;
                    rob[rob_tag].instr.is_start = DI[di_index].waiting_instruct.is_start;

                    IQ[i].valid = true;

                    IQ[i].queued = DI[di_index];
                    di_index++;
                }                
            }
            DI.clear();
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////// ISSUE() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Issue up to WIDTH oldest instructions
// from the IQ. (One approach to implement
// oldest-first issuing, is to make multiple
// passes through the IQ, each time finding
// the next oldest ready instruction and
// then issuing it. One way to annotate the
// age of an instruction is to assign an
// incrementing sequence number to each
// instruction as it is fetched from the
// trace file.)
// To issue an instruction:
// 1) Remove the instruction from the IQ.
// 2) Add the instruction to the
//    execute_list. Set a timer for the
//    instruction in the execute_list that
//    will allow you to model its execution
//    latency.

void Issue()
{
    int issued = 0;

    //Find width number of oldest instructions
    for(int j = 0; j < params.width; j++)  
    {
        int oldest = INT32_MAX;
        int oldest_index = -1;
        int empty_slot = -1;

        // searching for instruction with oldest sequence number
        for(int i = 0; i < params.iq_size; i++)
        {
            if(IQ[i].valid)
            {
                //if(IQ[oldest_index].queued.waiting_instruct.is_start == -1) IQ[oldest_index].queued.waiting_instruct.is_start = global_counter;

                if(IQ[i].queued.src1_ready && IQ[i].queued.src2_ready)
                {
                    if(IQ[i].queued.waiting_instruct.seq_no < oldest)
                    {
                        oldest = IQ[i].queued.waiting_instruct.seq_no;
                        oldest_index = i;
                    }
                }
            }
        }

        // searching for empty slot in execute list
        for(int k = 0; k < execute_list.size(); k++)
        {
          if(!execute_list[k].valid)  
          {
            empty_slot = k;
            break;
          }
        }

        if(empty_slot == -1) break;
        if(oldest_index == -1) break;
 
        int rob_tag = IQ[oldest_index].queued.waiting_instruct.dst_rob_tag;
        rob[rob_tag].instr.is_start = IQ[oldest_index].queued.waiting_instruct.is_start;

        // issuing instruction with the relevant latency  
        execute_list[empty_slot].instruct = IQ[oldest_index].queued;
        execute_list[empty_slot].execution_time = 0;  
        execute_list[empty_slot].valid = true;

        if(IQ[oldest_index].queued.waiting_instruct.operation_type == 0)
        {
            execute_list[empty_slot].latency = 1;
        }

        if(IQ[oldest_index].queued.waiting_instruct.operation_type == 1)
        {
            execute_list[empty_slot].latency = 2;
        }

        if(IQ[oldest_index].queued.waiting_instruct.operation_type == 2)
        {
            execute_list[empty_slot].latency = 5;
        }

        execute_list[empty_slot].instruct.waiting_instruct.ex_start = cycle_start + 1;

        //int rob_tag = IQ[oldest_index].queued.waiting_instruct.dst_rob_tag;
        rob[rob_tag].instr.ex_start = execute_list[empty_slot].instruct.waiting_instruct.ex_start;
        // Remove the instruction from the IQ
        IQ[oldest_index].valid = false;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////// EXECUTE() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// From the execute_list, check for
// instructions that are finishing
// execution this cycle, and:
// 1) Remove the instruction from
//    the execute_list.
// 2) Add the instruction to WB.
// 3) Wakeup dependent instructions (set
// their source operand ready flags) in
// the IQ, DI (the dispatch bundle), and
// RR (the register-read bundle).

void Execute()
{
    for(int i = 0; i < (params.width*5); i++)
    {
        if(execute_list[i].valid == false)   continue;

        execute_list[i].execution_time++;

        if(execute_list[i].valid && execute_list[i].latency == execute_list[i].execution_time)
        {
            instructions complete = execute_list[i].instruct.waiting_instruct;
            int completed_dst = complete.dst_rob_tag; //Completed instruction's destination for wakeup

            // Search for an empty slot in writeback and place the instruction there
            int empty_slot = -1;

            for(int k = 0; k < (params.width*5); k++)
            {
                if(!WB[k].valid)  
                {
                    empty_slot = k;
                    break;
                }
            }  
      
            if(empty_slot == -1) continue;

            WB[empty_slot].instruct.waiting_instruct = complete;       // Add instruction to writeback
            WB[empty_slot].valid = true;  
      
            //if(execute_list[i].instruct.waiting_instruct.ex_start == -1) execute_list[i].instruct.waiting_instruct.ex_start = global_counter;
            //execute_list[i].instruct.waiting_instruct.ex_start = cycle_start;
            //int rob_tag = execute_list[i].instruct.waiting_instruct.dst_rob_tag;

            //rob[rob_tag].instr.ex_start = execute_list[i].instruct.waiting_instruct.ex_start;

            execute_list[i].valid = false;          // Erasing from execute list

            //IQ wakeup
            for(int j = 0; j < params.iq_size; j++)
            {
                if(!IQ[j].valid) continue;              // will not check in empty locations

                if(completed_dst == IQ[j].queued.waiting_instruct.source1 && IQ[j].queued.waiting_instruct.rmt_source1)
                {
                    IQ[j].queued.src1_ready = true;
                }

                if(completed_dst == IQ[j].queued.waiting_instruct.source2 && IQ[j].queued.waiting_instruct.rmt_source2)
                {
                    IQ[j].queued.src2_ready = true;
                }
            }

            //DI Wakeup
            for(int j = 0; j < DI.size(); j++)
            {
                if(completed_dst == DI[j].waiting_instruct.source1 && DI[j].waiting_instruct.rmt_source1)
                {
                    DI[j].src1_ready = true;
                }

                if(completed_dst == DI[j].waiting_instruct.source2 && DI[j].waiting_instruct.rmt_source2)
                {
                    DI[j].src2_ready = true;
                }
            }

            //RR Wakeup
            for(int j = 0; j < RR.size(); j++)
            {
                if(completed_dst == RR[j].waiting_instruct.source1 && RR[j].waiting_instruct.rmt_source1)
                {
                    RR[j].src1_ready = true;
                }

                if(completed_dst == RR[j].waiting_instruct.source2 && RR[j].waiting_instruct.rmt_source2)
                {
                    RR[j].src2_ready = true;
                }
            }            
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////// WRITEBACK() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Process the writeback bundle in WB:
// For each instruction in WB, mark the
// instruction as “ready” in its entry in
// the ROB.

void Writeback()
{

    for (int i = 0; i < WB.size(); i++)
    {
        if(!WB[i].valid) continue;

        int dst_tag = WB[i].instruct.waiting_instruct.dst_rob_tag;

        if(dst_tag >=0 && dst_tag < rob.size() && rob[dst_tag].valid)  
        {
            rob[dst_tag].ready = true;
            rob[dst_tag].instr.rt_start = cycle_start + 1;
        }
        WB[i].instruct.waiting_instruct.wb_start = cycle_start;

        int rob_tag = WB[i].instruct.waiting_instruct.dst_rob_tag;
        rob[rob_tag].instr.wb_start = WB[i].instruct.waiting_instruct.wb_start;

        WB[i].valid = false;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////// RETIRE() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Retire up to WIDTH consecutive
// “ready” instructions from the head of
// the ROB.

void Retire()
{
    int retired = 0;

    while(retired < params.width && rob_count > 0)                    
    {
        //cout<<"rob[rob_head].ready = "<<rob[rob_head].ready<<endl;
        if(rob[rob_head].ready && rob[rob_head].valid)
        {
            // print first
            instructions &inst = rob[rob_head].instr;
            inst.rt_duration = unsigned(cycle_start - inst.rt_start + 1);
            inst.wb_duration = unsigned(inst.rt_start - inst.wb_start);
            inst.ex_duration = unsigned(inst.wb_start - inst.ex_start);
            inst.is_duration = unsigned(inst.ex_start - inst.is_start);
            inst.di_duration = unsigned(inst.is_start - inst.di_start);
            inst.rr_duration = unsigned(inst.di_start - inst.rr_start);
            inst.rn_duration = unsigned(inst.rr_start - inst.rn_start);
            inst.de_duration = unsigned(inst.rn_start - inst.de_start);
            inst.fe_duration = unsigned(inst.de_start - inst.fe_start);

            cout<< inst.seq_no<<" fu{"<<inst.operation_type<<"} "<<"src{"<<inst.source1<<","<<inst.source2<<"} "<<"dst{"<<inst.destination<<"} ";
            cout<<"FE{"<<inst.fe_start<<","<<inst.fe_duration<<"} ";
            cout<<"DE{"<<inst.de_start<<","<<inst.de_duration<<"} ";
            cout<<"RN{"<<inst.rn_start<<","<<inst.rn_duration<<"} ";
            cout<<"RR{"<<inst.rr_start<<","<<inst.rr_duration<<"} ";
            cout<<"DI{"<<inst.di_start<<","<<inst.di_duration<<"} ";
            cout<<"IS{"<<inst.is_start<<","<<inst.is_duration<<"} ";
            cout<<"EX{"<<inst.ex_start<<","<<inst.ex_duration<<"} ";
            cout<<"WB{"<<inst.wb_start<<","<<inst.wb_duration<<"} ";
            cout<<"RT{"<<inst.rt_start<<","<<inst.rt_duration<<"} "<<endl;

            // clearing rmt
            int dst = rob[rob_head].dst;
            if(dst != -1)
            {
                if(rmt[dst].rmt_rob_tag == rob_head)   rmt[dst].valid = false;
            }

            // clearing the rob entry
            rob[rob_head].ready = false;
            rob[rob_head].dst = -1;
            rob[rob_head].value = 0;
            rob[rob_head].rob_pc = 0;
            rob[rob_head].valid = false;

            rob_head = (rob_head + 1) % params.rob_size;
            rob_count--;
            retired++;            
        }
        else break;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////// ADVANCE_CYCLE() /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Advance_Cycle performs several functions.  
//First, it advances the simulator cycle.
//Second, when it becomes known that the  
//pipeline is empty AND the trace is depleted,
//the function returns “false” to terminate
//the loop.

bool Advance_Cycle()
{
    int cycle  = 0;
    global_counter++;
    cycle_start++;
    bool pipeline_empty = true;

    if(!DE.empty()) pipeline_empty = false;
    if(!RN.empty()) pipeline_empty = false;
    if(!RR.empty()) pipeline_empty = false;
    if(!DI.empty()) pipeline_empty = false;

    for (int i = 0; i < IQ.size(); i++)
    {
        if(IQ[i].valid)
        {
            pipeline_empty = false;
            break;
        }
    }

    for (int i = 0; i < execute_list.size(); i++)
    {
        if(execute_list[i].valid)
        {
            pipeline_empty = false;
            break;
        }
    }

    for (int i = 0; i < WB.size(); i++)
    {
        if(WB[i].valid)
        {
            pipeline_empty = false;
            break;
        }
    }

    for(int  i =0; i<rob.size(); i++)
    {
        if(rob[i].valid)
        {
            pipeline_empty = false;
            break;            
        }
    }

    if(pipeline_empty && trace_done)
    {
        return false;
    }

    else
    {
        return true;
    }
}